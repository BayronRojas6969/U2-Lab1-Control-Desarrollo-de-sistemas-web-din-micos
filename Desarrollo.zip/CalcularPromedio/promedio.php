<link rel="stylesheet" href="./assets/estilos/css/bootstrap.min.css">
<?php
    $nombre = $_POST['nombre'];
    $nota1 = $_POST['nota1'];
	$nota2 = $_POST['nota2'];
	$nota3 = $_POST['nota3'];
    $nota4 = $_POST['nota4'];
    $promedio = $_POST['promedio'] = round(($nota1 + $nota2 + $nota3 + $nota4)/4, 1);
	$mensaje = "";
	
	if($promedio>=4){
		$mensaje = "Has aprobado la asignatura!";
	}else{
        $mensaje = "REPROBADO!";
        if( isset($_POST['promedio']) && !empty($_POST['promedio'])){
            $nombre = $_POST['nombre'];

            echo '<script language="javascript">alert("REPROBADO! ");</script>';
        }
    }
        echo "El nombre ingresado fue: <b>$nombre</b><br>";
        echo "La nota 1 fue: <b>$nota1</b><br>";
        echo "La nota 2 fue: <b>$nota2</b><br>";
        echo "La nota 3 fue: <b>$nota3</b><br>";
        echo "La nota 4 fue: <b>$nota4</b><br>";
        echo "Asignatura: <b>Desarrollo de sistemas web dinámicos</b><br>";
		echo "El promedio de las cuatro notas son: <b>$promedio - $mensaje</b>";