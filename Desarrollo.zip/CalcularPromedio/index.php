<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" href="./assets/estilos/css/bootstrap.min.css">    
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <center><h1>Calculo de notas</h1></center>
    <form action="promedio.php" method="POST">
        <center><label for="">Nombre del estudiante:</label>
        <input type="text" name="nombre"><br>
        <label for="">Nota 1:</label>
        <input type="text" name="nota1"><br>
        <label for="">Nota 2:</label>
        <input type="text" name="nota2"><br>
        <label for="">Nota 3:</label>
        <input type="text" name="nota3"><br>
        <label for="">Nota 4:</label>
        <input type="text" name="nota4"><br>
        <button class="btn btn-dark">Calcular</button>
    </center>
    </form>
</body>